import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, NgModel } from '@angular/forms';
import { CoursesService } from '../services/courses.services';


@Component({
  // tslint:disable-next-line:component-selector
  selector: 'app-addCourses',
  templateUrl: './addCourses.component.html',
  styleUrls: ['./addCourses.component.css']
})
export class AddCoursesComponent implements OnInit {

  AddCoursesForm: FormGroup;

  constructor(private _CoursesService: CoursesService, private _fb: FormBuilder ) {
    this.AddCoursesForm = this._fb.group({
      // Id: 0,
      Name:  [null, [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
      Active: [1, [Validators.required]]
    });
  }

  ngOnInit() {
  }

  Save(): void {
    console.log('Saved');
    if (this.AddCoursesForm.valid) {
      this._CoursesService.Insert(this.AddCoursesForm.value).subscribe(() => {
        // this.toastr.success('Data saved successfully!', 'Add!');
        //  this.resetForm();
       });
    }
  }

}
