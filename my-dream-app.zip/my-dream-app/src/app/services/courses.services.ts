import { Injectable } from '@angular/core';
// Import Http & Response from angular HTTP module
import { HttpClient } from '@angular/common/http';
// Import Observable from rxjs/Observable
import { Observable } from 'rxjs/Observable';
// Import the map operator
import 'rxjs/add/operator/map';
// import { ISubjectarea } from '../models/subjectarea';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { ICourses } from '../models/courses';

@Injectable()
export class CoursesService {

    lsCourses: ICourses[];
    // Inject Angular http service
    constructor(private _httpClient: HttpClient) { }

    getAllCourses() {
        return this._httpClient.get('http://localhost:56147/api/Cours')
        .map((response) => <ICourses[]>response);
    }

    Insert(model) {
        return this._httpClient.post('http://localhost:56147/api/Cours', model)
            .map((response) => <ICourses>response);
    }

}
