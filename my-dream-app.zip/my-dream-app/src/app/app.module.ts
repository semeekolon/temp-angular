import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ShowCoursesComponent } from './showCourses/showCourses.component';

import { HttpClientModule } from '@angular/common/http'; // services

import { CoursesService } from './services/courses.services'; // Service
import { AddCoursesComponent } from './addCourses/addCourses.component';
import { RouterModule, Routes } from '@angular/router'; // Routing
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; // Reactive Forms


const appRoutes: Routes = [
  { path: 'showcourses', component: ShowCoursesComponent },
  { path: 'addcourses', component: AddCoursesComponent },

  {
   path: '', redirectTo: '/showcourses',
   pathMatch: 'full'
 }


];

@NgModule({
  declarations: [
    AppComponent,
    ShowCoursesComponent,
    AddCoursesComponent
],
  imports: [
    BrowserModule,
    HttpClientModule, // required for service
    RouterModule.forRoot(appRoutes), // Routing
    FormsModule, // Reactive Forms
    ReactiveFormsModule // Reactive Forms
  ],
  providers: [CoursesService], // Service
  bootstrap: [AppComponent]
})
export class AppModule { }
