export interface ICourses {
    Active: boolean;
    Id: number;
    Name: string;
}
