import { Component, OnInit } from '@angular/core';

import { ICourses } from '../models/courses';
import { CoursesService } from '../services/courses.services';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'app-showCourses',
  templateUrl: './showCourses.component.html',
  styleUrls: ['./showCourses.component.css']
})
export class ShowCoursesComponent implements OnInit {

  lsCourses: ICourses[];

  constructor(private _CoursesService: CoursesService ) { }

  ngOnInit() {
    this.populateData();
  }

  populateData() {
    this._CoursesService.getAllCourses()
       .subscribe(data => { this.lsCourses = data;  });
      // .subscribe(data => { console.log(data); });

  }

}
